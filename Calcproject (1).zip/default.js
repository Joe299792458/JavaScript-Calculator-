// The start function will run all of the commands that make up the calc function
function start(){
    calculator();  // This is the body of calculator 
    displayScreen(); // This is the orange screen where the number should show up 
    buttons(); // These buttons are green and grey sqaures on the calc
    buttonText(); // These are the numbers on the dials
    mouseClickMethod(clickMethod); // This command allows for the calc to press numbers 
  //  computhyation();
}

var NUMPAD = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, "CLR", "^2", ".", "/", "*", "-", "+", "="]; // Number dial for the calc
var entries = []; // This is the input list, so when the buttons get clicked the value goes in here 





// Colors used in the calculator
var DODGERB = new Color(30, 144, 255); //Color blue in the calc 
var DRAK = new Color(222,184,135);


// Below is the calculator peramenter
function calculator(){ 
    var rect = new Rectangle(250, 500);
    rect.setPosition(75, 50);
    rect.setColor(DRAK);
    add(rect);
}

// This is where the final result will show
function displayScreen(){
    var rect = new Rectangle(250, 100);
    rect.setPosition(75, 50);
    var cadium = new Color(0,128,128);
    rect.setColor(cadium);
    add(rect);
}

// This function is suppose to calculate everything inside of the array
function computation(){
    var place = 1;
    var num1 = 0;
    var num2 = 0;
    var numbers = [];// holds the number to be calculated into a decimal number
    var place = 1;
    var first = false;
    var operator = "+";
    for(var i = 0; i < entries.length; i++){
        println(entries[i]);
        if(entries[i] == 1 || entries[i] == 2 || entries[i] == 3 || entries[i] == 4 || entries[i] == 5 || entries[i] == 6 || entries[i] == 7 || entries[i] == 8 || entries[i] == 9){
            numbers.push(entries[i]);
            
        }
        else{
            if(entries[i] == "+" || entries[i] == "-" || entries[i] == "*" || entries[i] == "/"){
                operator = entries[i];
            }
           
            if(first == false){
                
                for(var j = numbers.length-1; j >= 0; j--){  // This turns the first set of numbers into one number
                    num1 += numbers[j] * place;
                    place *= 10;
                    println(num1 + "  " + place);
                }
                println(num1);
                first = true;
                numbers = [];
                place = 1;
            }
            else{
                for(var j = numbers.length-1; j >= 0; j--){ // This turns the second set of numbers into one number
                    num2 += numbers[j] * place;
                    place *= 10;
                    println(num2 + "  " + place);
                }
                println(num2);
                first = false;
                numbers = [];
                place = 1;
            }
            if(entries[i] == "="){
                if(operator == "+"){
                    addNums(num1, num2); 
                }
            }
        }
    }
}


function addNums(num1, num2){
    println(num1 + num2);
}









// The clickMethod function allows the calc to be interactive 
function clickMethod(e){
    //Key +40 for X values and -30 for Y values
    // X = 75, Y = 190
    if(e.getX() >= 75 &&
    e.getX() <= 115 && // This is a mouse click event for the clear button
    e.getY() >= 170 &&
    e.getY() <= 190){
        clearClicked();
    }
 
    // X = 145, Y = 190 
   if (e.getX() >= 145  && // Mouse click event for the decimal 
     e.getX()  <= 183  &&
     e.getY() >= 160  &&
     e.getY() <= 190 ){
         sqauredClicked();
        
     }
    
    // X = 220, Y = 190 -> button placements 
    if (e.getX() >= 220  && // Mouse click event for the decimal 
     e.getX()  <= 260  &&
     e.getY() >= 170  &&
     e.getY() <= 190 ){
         decimalClicked();
        
     }
     // X = 275, Y = 201
     if (e.getX() >= 275  && // Mouse click event for the div 
     e.getX()  <= 315  &&
     e.getY() >= 171  &&
     e.getY() <= 201 ){
         divisionClicked();
        
     }
    // X = 95, Y = 260
     if (e.getX() >= 95  && // Mouse click event for the 7 
     e.getX()  <= 135  &&
     e.getY() >= 230  &&
     e.getY() <= 260 ){
         sevenClicked();
        
     }
    // X = 155, Y = 260
     if (e.getX() >= 155  && // Mouse click event for the 8
     e.getX()  <= 195  &&
     e.getY() >= 230  &&
     e.getY() <= 260 ){
         eightClicked();
        
     }
    // X = 215, Y = 260
   if (e.getX() >= 215  && // Mouse click event for the 9
     e.getX()  <= 245  &&
     e.getY() >= 230  &&
     e.getY() <= 260 ){
         nineClicked();
        
     }
     // X = 270, Y = 270
     if (e.getX() >= 270  && // Mouse click event for the *
     e.getX()  <= 310  &&
     e.getY() >= 250  &&
     e.getY() <= 270 ){
         timesClicked();
        
     }
    // X = 93, Y = 320
      if (e.getX() >= 93  && // Mouse click event for the 4
     e.getX()  <= 133  &&
     e.getY() >= 290  &&
     e.getY() <= 320 ){
         fourClicked();
        
     }
    // X = 155, Y = 320
    if (e.getX() >= 155  && // Mouse click event for the 5
     e.getX()  <= 195  &&
     e.getY() >= 290  &&
     e.getY() <= 320 ){
         fiveClicked();
        
     }
     // X = 215, Y = 320
      if (e.getX() >= 215  && // Mouse click event for the 
     e.getX()  <= 245  &&
     e.getY() >= 290  &&
     e.getY() <= 320 ){
         sixClicked();
        
     }
     
    // X = 275, Y = 320
    if (e.getX() >= 275  && // Mouse click event for the -
     e.getX()  <= 315  &&
     e.getY() >= 290  &&
     e.getY() <= 320 ){
         minusClicked();
     }
     
    // X = 95, Y = 375
     if (e.getX() >= 95  && // Mouse click event for the 1
     e.getX()  <= 133  &&
     e.getY() >= 345  &&
     e.getY() <= 375 ){
         oneClicked();
        
     }
     // X = 155, Y = 375
     if (e.getX() >= 155  && // Mouse click event for the 2
     e.getX()  <= 195  && // fixing
     e.getY() >= 345  &&
     e.getY() <= 375 ){
         twoClicked();
        
     }
     // X = 215, Y = 375
     if (e.getX() >= 215  && // Mouse click event for the 3
     e.getX()  <= 255  &&  // fixing 
     e.getY() >= 345  &&
     e.getY() <= 375 ){
         threeClicked();
        
     }
     // X = 269, Y = 380
     if (e.getX() >= 269  && // Mouse click event for the +
     e.getX()  <= 309  &&
     e.getY() >= 350  && // fixed
     e.getY() <= 380 ){
         plusClicked();
        
     }
   
   
   // X = 120, Y = 445
    if (e.getX() >= 120  && // Mouse click event for the 0
     e.getX()  <= 160  &&
     e.getY() >= 415  &&
     e.getY() <= 445 ){
         zeroClicked();
        
     } 
   // X = 235, Y = 459
   if (e.getX() >= 235  && // Mouse click event for the =
     e.getX()  <= 275  &&
     e.getY() >= 429  &&
     e.getY() <= 459 ){
         equalClicked();
        
     }
     
}


 
// This function responds when clear has been clicked
function clearClicked(){
    entries = [];
    println(entries);
}

// This function responds when the sqaured root has been been clicked
function sqauredClicked(){
     entries.push("^2");
    println(entries);
}

// This function responds when the decimal button has been clicked
function decimalClicked(){
   entries.push(".");
   println(entries);
}
    
// This function responds when the division symbol has been clicked
function divisionClicked(){
    entries.push("/");
   println(entries);
}

// This function responds when the number 7 has been clicked
function sevenClicked(){
    entries.push(7);
   println(entries);
}

// This function responds when the number 8 has been clicked
function eightClicked(){
    entries.push(8);
    println(entries);
}

// This function responds when the number 9 has been clicked
function nineClicked(){
    entries.push(9);
    println(entries);
}

function timesClicked(){
    entries.push("*");
    println(entries);
}

// This function responds when the number 4 has been clicked
function fourClicked(){
    entries.push(4);
    println(entries);
}

// This function responds when the number 5 has been clicked 
function fiveClicked(){
    entries.push(5);
    println(entries);
}

// THis function responds when the number 6 has been clicked
function sixClicked(){
     entries.push(6);
    println(entries);
}

// This function responds when the minus sign has been clicked 
function minusClicked(){
     entries.push("-");
    println(entries);
}

// This function responds when number one has been clicked
function oneClicked(){
     entries.push(1);
    println(entries);
}

// This function responds when number two has been clicked
function twoClicked(){
    entries.push(2);
    println(entries);
}

// This function responds with the number three when number three has been clicked
function threeClicked(){
     entries.push(3);
    println(entries);
}

//This function responds with + the plus sign has been clicked
function plusClicked(){
     entries.push("+");
    println(entries);
}

// This function responds with 0 when the 0 button has been clicked
function zeroClicked(){
     entries.push(0);
    println(entries);
}

// This function responds with the final number when it has been clicked
function equalClicked(){
     entries.push("=");
    println(entries);
    computation();
}

function buttonText(){ // This is how I will place the digits 
    
    var txt = new Text("CLR", "20pt Arial"); // clear text
    txt.setPosition(75, 190);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("^2", "20pt Arial"); // sqaure root
    txt.setPosition(145, 190);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text(".", "50pt Arial"); // decimal
    txt.setPosition(220, 190);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("/", "45pt Arial"); // division
    txt.setPosition(275, 201);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("7", "20pt Arial"); // num 7
    txt.setPosition(95, 260);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("8", "20pt Arial"); // num 8
    txt.setPosition(155, 260);
    txt.setColor(Color.black);
    add(txt);
    
    
      var txt = new Text("9", "20pt Arial"); // num 9 
    txt.setPosition(215, 260);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("*", "40pt Arial"); //multiplication sign (*)
    txt.setPosition(270, 280);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("4", "20pt Arial"); // num 4
    txt.setPosition(95, 320);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("5", "20pt Arial"); // num 5 
    txt.setPosition(155, 320);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("6", "20pt Arial"); // num 6
    txt.setPosition(215, 320);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("-", "30pt Arial"); // subtraction (-)
    txt.setPosition(275, 320);
    txt.setColor(Color.black);
    add(txt);
    
    
    var txt = new Text("1", "20pt Arial"); // num 1
    txt.setPosition(95, 375);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("2", "20pt Arial"); // num 2
    txt.setPosition(155, 375);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("3", "20pt Arial"); // num 3
    txt.setPosition(215, 375);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("+", "30pt Arial"); // addition sign
    txt.setPosition(269, 380);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("0", "20pt Arial"); // num 0
    txt.setPosition(120, 445);
    txt.setColor(Color.black);
    add(txt);
    
    var txt = new Text("=", "50pt Arial"); // equal sign (=)
    txt.setPosition(235, 459);
    txt.setColor(Color.black);
    add(txt);
    

    
}



function buttons(){ // This is the buttons 
    //first row
    //Cyan colored buttons will be specialized buttons 
    //Grey colored butttons with be the normal num dial pad
  
    
    var rect = new Rectangle(55, 55); // clear button
    rect.setPosition(75, 153);
    rect.setColor(DODGERB);
    add(rect);
    
   
    var rect = new Rectangle(55, 55); //sqaure root
    rect.setPosition(135, 153);
    rect.setColor(DODGERB);
    add(rect);
    
    
    var rect = new Rectangle(55, 55);   // decimal
    rect.setPosition(195, 153);
    rect.setColor(DODGERB);
    add(rect);
    

    var rect = new Rectangle(55, 55);     //division
    rect.setPosition(255, 153);
    rect.setColor(DODGERB);
    add(rect);
    
    // second row
   
     var rect = new Rectangle(55, 55); //num 7
    rect.setPosition(75, 220);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // num 8
    rect.setPosition(135, 220);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // num 9
    rect.setPosition(195, 220);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // multiplication sign (-)
    rect.setPosition(255, 220);
    rect.setColor(DODGERB);
    add(rect);
    
    //Thrid row 
    
    var rect = new Rectangle(55, 55); // num 4
    rect.setPosition(75, 280);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // num 5
    rect.setPosition(135, 280);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // num 6
    rect.setPosition(195, 280);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // subtraction (-)
    rect.setPosition(255, 280);
    rect.setColor(DODGERB);
    add(rect);
    
    // fourth row
    
    var rect = new Rectangle(55, 55); //num 1
    rect.setPosition(75, 340);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // num 2
    rect.setPosition(135, 340);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // num 3
    rect.setPosition(195, 340);
    rect.setColor(Color.grey);
    add(rect);
    
    
    var rect = new Rectangle(55, 55); // addition sign (+)
    rect.setPosition(255, 340);
    rect.setColor(DODGERB);
    add(rect);
    
    //  fifth row 
    
     var rect = new Rectangle(115, 55); //num 0
    rect.setPosition(75, 410);
    rect.setColor(Color.grey);
    add(rect);
    

    
    var rect = new Rectangle(115, 55); // equalsign (=)
    rect.setPosition(195, 410);
    rect.setColor(DODGERB);
    add(rect);
    
}